package javaLearning;

import java.util.Scanner;

public class MultiplierDemo {

	public static void main(String[] args) {

		// Create an object of Scanner class to read input from user
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the numbers");

		int[] numArr = new int[5];
		// For loop for User to enter the 5 numbers
		for (int i = 0; i < numArr.length; i++) {

			numArr[i] = sc.nextInt();
		}

		int arrCount = findMultiples(numArr);

		// To print the Input array of numbers and the result array of numbers
		System.out.println("\nInput and Result array size: " + numArr.length + "  " + arrCount);

	}

	/*
	 * Function to pass the argument as integer array and return the number of
	 * values that are multiplier of 4 or 6 or both
	 */

	private static int findMultiples(int[] numArr) {
		int counter = 0;
		System.out.println("Multiplier array: ");

		for (int i = 0; i < numArr.length; i++) {
			if (numArr[i] % 4 == 0 || numArr[i] % 6 == 0) {
				System.out.println(numArr[i] + " ");
				counter++;
			}
		}
		return counter;

	}
}
