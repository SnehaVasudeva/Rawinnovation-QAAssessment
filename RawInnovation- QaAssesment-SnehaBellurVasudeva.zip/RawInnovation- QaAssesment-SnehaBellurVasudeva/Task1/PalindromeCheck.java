package javaLearning;

import java.util.Scanner;

public class PalindromeCheck {

	public static void main(String[] args) {
		
		//Create an object of Scanner class to read input
		Scanner in= new Scanner(System.in);
		
		System.out.println("Enter the String\n ");
		
		//Gets the  value of String from the User
		String str=in.nextLine();
		
		checkPalindrome(str);
	}
	
	public static void checkPalindrome(String str)
	{
		
		//Create a temporary variable to store the value as entered by user
		String strTemp= str;
		
		String revPal= "";
		
		//Get the length of the string
		
		int len=str.length();
		
		//The for loop runs from the end to the beginning of the string.
		for(int i=len-1;i>=0;i--)
		{
			revPal=revPal+str.charAt(i); //The charAt() method accesses each character of the string.
		}
		
		//if statement to compare original String and reverse String
		
		if(strTemp.toLowerCase().equals(revPal.toLowerCase())) //The toLowerCase() method converts both strTemp and revPal to lowercase. 
		{
			System.out.println(strTemp +" "+"- Palindrome number");
		}
		
		else
		
		{
			System.out.println(strTemp +" "+"-Palindrome number");
		}
	}
}

